var searchData=
[
  ['bcdadj',['BCDADJ',['../iodefine__ext_8h.html#a31f8dffbed9b41c7e97b75f1e12f68e3',1,'iodefine_ext.h']]],
  ['bothcode',['bothCode',['../global_8h.html#a724cd295a2bdb384cec34339e5310128',1,'global.h']]],
  ['brk_5fi_5fvect',['BRK_I_vect',['../iodefine_8h.html#ac4db06b9ea0cc84129fdea5d04856ae4',1,'iodefine.h']]],
  ['btnclose',['btnClose',['../global_8h.html#aeba2f8ca762d59cd8bd0daa24ceb6f6d',1,'global.h']]],
  ['btnopen',['btnOpen',['../global_8h.html#af563614a816647fe384d6a7650af2e78',1,'global.h']]]
];
