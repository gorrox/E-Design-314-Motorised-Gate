var searchData=
[
  ['opencode',['openCode',['../global_8h.html#a957b1bb3f965780cb5df3494408067a7',1,'global.h']]],
  ['option_5fsect',['OPTION_SECT',['../r__cg__vector__table_8c.html#a845084c7d97105eac92f0a41b4e5c55f',1,'r_cg_vector_table.c']]],
  ['osmc',['OSMC',['../iodefine__ext_8h.html#a0eee1503928654592ba15567d74ddf66',1,'iodefine_ext.h']]],
  ['ostc',['OSTC',['../iodefine_8h.html#affcdea827309214f7cd75ff072c259eb',1,'iodefine.h']]],
  ['ostc_5fbit',['OSTC_bit',['../iodefine_8h.html#ac7d9f26df75e2a1023e6a0d2541c7a90',1,'iodefine.h']]],
  ['osts',['OSTS',['../iodefine_8h.html#a84e8ce97564ef5077ec6019520aa57d6',1,'iodefine.h']]]
];
