var searchData=
[
  ['transmit',['transmit',['../global_8c.html#a29ff55f7ca3b7d4a69af0648518423a3',1,'transmit(void):&#160;global.c'],['../global_8h.html#a29ff55f7ca3b7d4a69af0648518423a3',1,'transmit(void):&#160;global.c']]]
];
