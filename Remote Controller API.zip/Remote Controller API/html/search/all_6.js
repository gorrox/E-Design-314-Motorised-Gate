var searchData=
[
  ['flif',['FLIF',['../iodefine_8h.html#a42f58c98087971c49c6374d606a577e1',1,'iodefine.h']]],
  ['flmk',['FLMK',['../iodefine_8h.html#a5fa37dc396cfb344922b325f028908ce',1,'iodefine.h']]],
  ['flpr0',['FLPR0',['../iodefine_8h.html#aabdb5dbf4bcbc639ca8cf1344ab85c52',1,'iodefine.h']]],
  ['flpr1',['FLPR1',['../iodefine_8h.html#a1ee331221767e28888aef2fa061d0205',1,'iodefine.h']]],
  ['framebase',['frameBase',['../global_8h.html#a481cad208126578f107e4ccbbe884d03',1,'global.h']]],
  ['framebasedef',['frameBaseDef',['../global_8h.html#aa5d74f8d0eff4822b9f592e444f9d43e',1,'global.h']]],
  ['framehalfbitlength',['frameHalfBitLength',['../global_8h.html#a83eff6f608824464822150d9351df9a1',1,'global.h']]],
  ['fullhalfbitlength',['fullHalfBitLength',['../global_8h.html#af85d2720cfa652e51a1b24e0878dbaff',1,'global.h']]]
];
