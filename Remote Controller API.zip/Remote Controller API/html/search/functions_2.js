var searchData=
[
  ['core',['core',['../global_8c.html#acda2e61e91ee7d8170c59f0e441814bd',1,'core(void):&#160;global.c'],['../global_8h.html#acda2e61e91ee7d8170c59f0e441814bd',1,'core(void):&#160;global.c']]]
];
