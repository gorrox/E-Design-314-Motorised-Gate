var searchData=
[
  ['framebase',['frameBase',['../global_8h.html#a481cad208126578f107e4ccbbe884d03',1,'global.h']]]
];
