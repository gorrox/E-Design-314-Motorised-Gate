var searchData=
[
  ['btnclosetriggered',['btnCloseTriggered',['../global_8c.html#af58942166ee66874b35ad73dcc777d82',1,'btnCloseTriggered(void):&#160;global.c'],['../global_8h.html#af58942166ee66874b35ad73dcc777d82',1,'btnCloseTriggered(void):&#160;global.c']]],
  ['btnopentriggered',['btnOpenTriggered',['../global_8c.html#a49bcb9752086a9d01c31f5f74d160365',1,'btnOpenTriggered(void):&#160;global.c'],['../global_8h.html#a49bcb9752086a9d01c31f5f74d160365',1,'btnOpenTriggered(void):&#160;global.c']]]
];
