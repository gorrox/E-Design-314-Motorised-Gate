var searchData=
[
  ['key_5fwaittime',['KEY_WAITTIME',['../r__cg__intc_8h.html#afbc6c34230343800a840f840bd421640',1,'r_cg_intc.h']]],
  ['krctl',['krctl',['../unionun__krctl.html#a6d364d808a65bce5c0965d26a645e160',1,'un_krctl::krctl()'],['../iodefine_8h.html#a8b448e501af9880642e3141bdf67970d',1,'KRCTL():&#160;iodefine.h']]],
  ['krctl_5fbit',['KRCTL_bit',['../iodefine_8h.html#aecb14ccb5d0e84b5de9b4c3a5de90e61',1,'iodefine.h']]],
  ['krf',['KRF',['../iodefine_8h.html#a7c75563f878482260e7f9e677958e963',1,'iodefine.h']]],
  ['krif',['KRIF',['../iodefine_8h.html#a1f9cedec5534e621f93b0d7211c2e1e4',1,'iodefine.h']]],
  ['krm0',['krm0',['../unionun__krm0.html#af54d620a75fc4ef9045df5af3d96427b',1,'un_krm0::krm0()'],['../iodefine_8h.html#a0b16baa4a744beb8fc92da7005846331',1,'KRM0():&#160;iodefine.h']]],
  ['krm0_5fbit',['KRM0_bit',['../iodefine_8h.html#a4cb9ddf3b489911c5889fbd451411aed',1,'iodefine.h']]],
  ['krmk',['KRMK',['../iodefine_8h.html#a249998aa78e5933edda51068d4008ba8',1,'iodefine.h']]],
  ['krpr0',['KRPR0',['../iodefine_8h.html#a6621118a5a749717707f307edefe74ad',1,'iodefine.h']]],
  ['krpr1',['KRPR1',['../iodefine_8h.html#af8e7ebb9b8a7d2d2491c0d34823d53e5',1,'iodefine.h']]]
];
