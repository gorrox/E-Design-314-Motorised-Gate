var searchData=
[
  ['check_5fbtns',['check_btns',['../global_8h.html#a26b7b25b333717601b9be3a3fe8de8fd',1,'global.h']]],
  ['ckc',['ckc',['../unionun__ckc.html#aa4bebcd8cc1078c39d49073785386dbd',1,'un_ckc']]],
  ['cks0',['cks0',['../unionun__cks0.html#aec8075f8be65da3729fd23557a032d96',1,'un_cks0']]],
  ['cks1',['cks1',['../unionun__cks1.html#a7198a77c2bdbbb917e477864582fad5d',1,'un_cks1']]],
  ['collision_5fdet',['collision_det',['../adc_8h.html#a40872573b1293e605460a1dcde09cb42',1,'adc.h']]],
  ['collision_5fdet_5fcounter',['collision_det_counter',['../adc_8h.html#ae8dc144677749a82a03a645bb1d25d73',1,'adc.h']]],
  ['crc0ctl',['crc0ctl',['../unionun__crc0ctl.html#ad6cff181e3f830fff2e5494944c181e8',1,'un_crc0ctl']]],
  ['csc',['csc',['../unionun__csc.html#a45d5c074d4cdd26253a09cb9d41b07b0',1,'un_csc']]],
  ['ctrlmode',['ctrlMode',['../global_8h.html#a80c59c658490b004da751ed685bd6bba',1,'global.h']]]
];
