var searchData=
[
  ['lcd_5fclear',['lcd_clear',['../lcd_8c.html#a35c08b1fa742e650f4873939707b893b',1,'lcd_clear():&#160;lcd.c'],['../lcd_8h.html#a35c08b1fa742e650f4873939707b893b',1,'lcd_clear():&#160;lcd.c']]]
];
