var searchData=
[
  ['g_5fuart1_5frx_5fcount',['g_uart1_rx_count',['../r__cg__serial_8c.html#a5862e43142f32fe39ba5bc492d90dc27',1,'g_uart1_rx_count():&#160;r_cg_serial.c'],['../r__cg__serial__user_8c.html#a5862e43142f32fe39ba5bc492d90dc27',1,'g_uart1_rx_count():&#160;r_cg_serial.c']]],
  ['g_5fuart1_5frx_5flength',['g_uart1_rx_length',['../r__cg__serial_8c.html#ac31ca3744f70e7fa6c9172f3dd0b578d',1,'g_uart1_rx_length():&#160;r_cg_serial.c'],['../r__cg__serial__user_8c.html#ac31ca3744f70e7fa6c9172f3dd0b578d',1,'g_uart1_rx_length():&#160;r_cg_serial.c']]],
  ['g_5fuart1_5ftx_5fcount',['g_uart1_tx_count',['../r__cg__serial_8c.html#ae7a73cfb19d47d9f9cc4c65fca7fa6ed',1,'g_uart1_tx_count():&#160;r_cg_serial.c'],['../r__cg__serial__user_8c.html#ae7a73cfb19d47d9f9cc4c65fca7fa6ed',1,'g_uart1_tx_count():&#160;r_cg_serial.c']]],
  ['gate_5fcmd',['gate_cmd',['../global_8h.html#a37b4b6ab17d64f20396f345c7680aad1',1,'global.h']]],
  ['gate_5fstatus',['gate_status',['../global_8h.html#a97d30bd3010754851ec1c44e81821a62',1,'global.h']]],
  ['gdidis',['gdidis',['../unionun__gdidis.html#ad036dba0053f269f8ee1716e1b92bcc0',1,'un_gdidis']]],
  ['gp_5fuart1_5frx_5faddress',['gp_uart1_rx_address',['../r__cg__serial_8c.html#aa3796533eb439947635697f53af665d0',1,'gp_uart1_rx_address():&#160;r_cg_serial.c'],['../r__cg__serial__user_8c.html#aa3796533eb439947635697f53af665d0',1,'gp_uart1_rx_address():&#160;r_cg_serial.c']]],
  ['gp_5fuart1_5ftx_5faddress',['gp_uart1_tx_address',['../r__cg__serial_8c.html#a8a6840395921df259f53f94df5c4e6f6',1,'gp_uart1_tx_address():&#160;r_cg_serial.c'],['../r__cg__serial__user_8c.html#a8a6840395921df259f53f94df5c4e6f6',1,'gp_uart1_tx_address():&#160;r_cg_serial.c']]]
];
