var searchData=
[
  ['status',['status',['../global_8h.html#a015eb90e0de9f16e87bd149d4b9ce959',1,'global.h']]]
];
