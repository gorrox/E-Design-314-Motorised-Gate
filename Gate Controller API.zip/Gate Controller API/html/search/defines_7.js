var searchData=
[
  ['gdidis',['GDIDIS',['../iodefine__ext_8h.html#a8d16f3ae4cda468e44581857c71d694b',1,'iodefine_ext.h']]],
  ['gdidis_5fbit',['GDIDIS_bit',['../iodefine__ext_8h.html#af993f0dfb87d3176bf80356911d0dec4',1,'iodefine_ext.h']]]
];
