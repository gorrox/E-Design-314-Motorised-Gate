var searchData=
[
  ['rtc_5fhour_5fsystem_5ft',['rtc_hour_system_t',['../r__cg__rtc_8h.html#a7e419d0237d55c887ccad1ac5be47e64',1,'r_cg_rtc.h']]],
  ['rtc_5fint_5fperiod_5ft',['rtc_int_period_t',['../r__cg__rtc_8h.html#a79ca55bfef40a7cc6702f2011323735c',1,'r_cg_rtc.h']]]
];
