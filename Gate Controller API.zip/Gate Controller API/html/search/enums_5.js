var searchData=
[
  ['test_5fchannel_5ft',['test_channel_t',['../r__cg__adc_8h.html#a8615bdf67c10a285f06f29fb39c872d1',1,'r_cg_adc.h']]],
  ['timer_5fchannel_5ft',['timer_channel_t',['../r__cg__timer_8h.html#a6bb52d3cbff513eadd58a6e79de3aa10',1,'r_cg_timer.h']]]
];
