var searchData=
[
  ['unknown',['UNKNOWN',['../global_8h.html#a015eb90e0de9f16e87bd149d4b9ce959a6ce26a62afab55d7606ad4e92428b30c',1,'global.h']]]
];
