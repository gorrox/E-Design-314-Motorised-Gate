var searchData=
[
  ['normal',['NORMAL',['../global_8h.html#a1a6b6fb557d8d37d59700faf4e4c9167a50d1448013c6f17125caee18aa418af7',1,'global.h']]]
];
