var searchData=
[
  ['echo',['echo',['../global_8c.html#a60a68989910373f228af45371b269f32',1,'echo(uint8_t hex):&#160;global.c'],['../global_8h.html#a60a68989910373f228af45371b269f32',1,'echo(uint8_t hex):&#160;global.c']]],
  ['echodata',['echoData',['../global_8c.html#a2cb0f2ec2a45db5bd3c5918e6e4eed96',1,'echoData(uint8_t hex, uint8_t hex2):&#160;global.c'],['../global_8h.html#a2cb0f2ec2a45db5bd3c5918e6e4eed96',1,'echoData(uint8_t hex, uint8_t hex2):&#160;global.c']]]
];
