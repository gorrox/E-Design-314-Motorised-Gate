var searchData=
[
  ['closed',['CLOSED',['../global_8h.html#a015eb90e0de9f16e87bd149d4b9ce959a929f0327e17604ce9713b2a6117bd603',1,'global.h']]]
];
