var searchData=
[
  ['testlcdconnections',['testLCDConnections',['../lcd_8c.html#af298668bb883ef6447f38de479f068a7',1,'testLCDConnections(void):&#160;lcd.c'],['../lcd_8h.html#af298668bb883ef6447f38de479f068a7',1,'testLCDConnections(void):&#160;lcd.c']]],
  ['tobcd',['toBCD',['../global_8c.html#a75c9e91eaed969ac63f30108e5a4d7eb',1,'toBCD(uint8_t hex):&#160;global.c'],['../global_8h.html#a75c9e91eaed969ac63f30108e5a4d7eb',1,'toBCD(uint8_t hex):&#160;global.c']]],
  ['tohex',['toHex',['../global_8c.html#a9b867d2dbc2d78317b5644fe4f48b0bb',1,'toHex(uint8_t decimal):&#160;global.c'],['../global_8h.html#a9b867d2dbc2d78317b5644fe4f48b0bb',1,'toHex(uint8_t decimal):&#160;global.c']]]
];
