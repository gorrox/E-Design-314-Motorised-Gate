var searchData=
[
  ['hour',['hour',['../structrtc__counter__value__t.html#ae5af4ff48939d13d480f87e56a9385d6',1,'rtc_counter_value_t']]]
];
