var searchData=
[
  ['rtc_5falarm_5fvalue_5ft',['rtc_alarm_value_t',['../structrtc__alarm__value__t.html',1,'']]],
  ['rtc_5fcounter_5fvalue_5ft',['rtc_counter_value_t',['../structrtc__counter__value__t.html',1,'']]]
];
