var searchData=
[
  ['key_5fwaittime',['KEY_WAITTIME',['../r__cg__intc_8h.html#afbc6c34230343800a840f840bd421640',1,'r_cg_intc.h']]],
  ['krif',['KRIF',['../iodefine_8h.html#a1f9cedec5534e621f93b0d7211c2e1e4',1,'iodefine.h']]],
  ['krm',['KRM',['../iodefine_8h.html#af052f35526d892ad299693e05dc198d9',1,'iodefine.h']]],
  ['krm_5fbit',['KRM_bit',['../iodefine_8h.html#a83cd61fb9cb5a39467ac5afedc958915',1,'iodefine.h']]],
  ['krmk',['KRMK',['../iodefine_8h.html#a249998aa78e5933edda51068d4008ba8',1,'iodefine.h']]],
  ['krpr0',['KRPR0',['../iodefine_8h.html#a6621118a5a749717707f307edefe74ad',1,'iodefine.h']]],
  ['krpr1',['KRPR1',['../iodefine_8h.html#af8e7ebb9b8a7d2d2491c0d34823d53e5',1,'iodefine.h']]]
];
