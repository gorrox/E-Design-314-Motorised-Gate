var searchData=
[
  ['adc',['ADC',['../adc_8c.html#a5c873012d494d2498d4acef70189e93b',1,'ADC(void):&#160;adc.c'],['../adc_8h.html#a5c873012d494d2498d4acef70189e93b',1,'ADC(void):&#160;adc.c']]],
  ['adc_5fget_5freading',['adc_get_reading',['../adc_8c.html#a1f7216945d914a127f5e899ef5a1af4f',1,'adc_get_reading(void):&#160;adc.c'],['../adc_8h.html#a1f7216945d914a127f5e899ef5a1af4f',1,'adc_get_reading(void):&#160;adc.c']]]
];
