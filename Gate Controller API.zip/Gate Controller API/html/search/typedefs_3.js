var searchData=
[
  ['status',['status',['../global_8h.html#a2c752f159582e378f8a15b1e5fd6308f',1,'global.h']]]
];
