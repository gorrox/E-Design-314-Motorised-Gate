var searchData=
[
  ['uartreceive',['uartReceive',['../global_8c.html#a3b98d41b3fe6545f6dbd754131d8af8d',1,'uartReceive(void):&#160;global.c'],['../global_8h.html#a3b98d41b3fe6545f6dbd754131d8af8d',1,'uartReceive(void):&#160;global.c']]],
  ['uartsend',['uartSend',['../global_8c.html#ab3b0160b9202002c8b09d8197267d068',1,'uartSend(void):&#160;global.c'],['../global_8h.html#ab3b0160b9202002c8b09d8197267d068',1,'uartSend(void):&#160;global.c']]]
];
