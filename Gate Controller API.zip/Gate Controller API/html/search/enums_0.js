var searchData=
[
  ['ad_5fchannel_5ft',['ad_channel_t',['../r__cg__adc_8h.html#a3e162c43f78d7f162b00e9740f78761b',1,'r_cg_adc.h']]]
];
