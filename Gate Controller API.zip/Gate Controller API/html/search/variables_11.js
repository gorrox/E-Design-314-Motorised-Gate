var searchData=
[
  ['uart1rxbuf',['uart1RxBuf',['../global_8h.html#ac44426334de8c8b37b647cd617bb817a',1,'global.h']]],
  ['uart1rxcnt',['uart1RxCnt',['../global_8h.html#a3924762a091f385c4d929e16570a8caa',1,'global.h']]],
  ['uart1rxflag',['uart1RxFlag',['../global_8h.html#a657de864e445651fff2129f01da2b6af',1,'global.h']]],
  ['uart1status',['uart1Status',['../global_8h.html#a04e5b1a32998b9ccb7c96ad8c8de153e',1,'global.h']]],
  ['uart1txbuf',['uart1TxBuf',['../global_8h.html#ac12f041834da220ea6061577cac7bf81',1,'global.h']]],
  ['uart1txcnt',['uart1TxCnt',['../global_8h.html#acce652cca20c9045fc5a1905359327bb',1,'global.h']]],
  ['uart1txflag',['uart1TxFlag',['../global_8h.html#a49d2ecd331586c233c1c48595830b809',1,'global.h']]]
];
