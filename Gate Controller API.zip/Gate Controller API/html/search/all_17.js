var searchData=
[
  ['year',['year',['../structrtc__counter__value__t.html#a7af2065789bc84419b8d5fe109be83b5',1,'rtc_counter_value_t::year()'],['../iodefine_8h.html#a5871356500f559add06ea81d60331b1b',1,'YEAR():&#160;iodefine.h']]]
];
