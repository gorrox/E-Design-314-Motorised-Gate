var searchData=
[
  ['mode',['mode',['../global_8h.html#a1a6b6fb557d8d37d59700faf4e4c9167',1,'global.h']]]
];
