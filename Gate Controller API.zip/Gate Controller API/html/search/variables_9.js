var searchData=
[
  ['latest_5fcurrent_5freading',['latest_current_reading',['../adc_8h.html#a4dfc1d6cc3c9694e2fda7430632b36b8',1,'adc.h']]],
  ['lvim',['lvim',['../unionun__lvim.html#ad7914278f251438fe9afbd6e28663b1c',1,'un_lvim']]],
  ['lvis',['lvis',['../unionun__lvis.html#adc9e7f3074115ea2a5c7b8336394e714',1,'un_lvis']]]
];
