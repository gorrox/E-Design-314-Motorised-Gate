var searchData=
[
  ['sendrtc',['sendRTC',['../global_8c.html#a98f44ad339e8256b0e8c365fe4014e07',1,'sendRTC(void):&#160;global.c'],['../global_8h.html#a98f44ad339e8256b0e8c365fe4014e07',1,'sendRTC(void):&#160;global.c']]],
  ['setrtc',['setRTC',['../global_8c.html#aabd00457c16e8c6a57736709afa9a805',1,'setRTC(void):&#160;global.c'],['../global_8h.html#aabd00457c16e8c6a57736709afa9a805',1,'setRTC(void):&#160;global.c']]],
  ['starttmr0',['startTMR0',['../lcd_8c.html#a9ee3f6a1fed58148c9bbacf340b66445',1,'startTMR0(int delay):&#160;lcd.c'],['../lcd_8h.html#a9ee3f6a1fed58148c9bbacf340b66445',1,'startTMR0(int delay):&#160;lcd.c']]],
  ['stopgate',['stopGate',['../global_8c.html#a69605c49f48293ed9ed8cd3afe6563c7',1,'stopGate(void):&#160;global.c'],['../global_8h.html#a69605c49f48293ed9ed8cd3afe6563c7',1,'stopGate(void):&#160;global.c']]]
];
