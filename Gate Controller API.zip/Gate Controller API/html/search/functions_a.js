var searchData=
[
  ['opengate',['openGate',['../global_8c.html#aa42f9f7097d75ea636c1662a0403b3f1',1,'openGate(void):&#160;global.c'],['../global_8h.html#aa42f9f7097d75ea636c1662a0403b3f1',1,'openGate(void):&#160;global.c']]]
];
